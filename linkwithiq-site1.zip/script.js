// ---- shared: respect the user's motion preference everywhere, once ----

const PREFERS_REDUCED_MOTION = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// ---- only follow links / images from the GitHub API if they really point at GitHub ----
function safeGitHubUrl(value, allowedHosts) {
  try {
    const u = new URL(String(value));
    return u.protocol === 'https:' && allowedHosts.includes(u.hostname) ? u.href : null;
  } catch (e) { return null; }
}

// ---- loading screen: draw the logo in, then fill it, then reveal the site ----
(function initLoadingScreen(){
  const loader = document.getElementById('loadingScreen');
  if (!loader) return;

  function finishLoading(){
    loader.classList.add('done');
    document.body.classList.remove('is-loading');
  }

  const outer = document.getElementById('loadingPathOuter');
  const drop = document.getElementById('loadingPathDrop');
  const wordmark = document.getElementById('loadingWordmark');

  if (PREFERS_REDUCED_MOTION || !outer || !drop || typeof outer.getTotalLength !== 'function') {
    // no draw animation — just a quick, simple reveal
    setTimeout(finishLoading, 250);
    return;
  }

  try {
    [outer, drop].forEach(path => {
      const len = path.getTotalLength();
      path.style.strokeDasharray = String(len);
      path.style.strokeDashoffset = String(len);
    });

    let settled = false;
    const safeFinish = function(){
      if (settled) return;
      settled = true;
      finishLoading();
    };

    // fill in (and reveal the wordmark) once the drop stroke has finished drawing
    const onStrokeDone = function(e){
      if (e.propertyName !== 'stroke-dashoffset') return;
      drop.removeEventListener('transitionend', onStrokeDone);
      outer.style.fillOpacity = '1';
      drop.style.fillOpacity = '1';
      if (wordmark) wordmark.classList.add('visible');
    };
    drop.addEventListener('transitionend', onStrokeDone);

    // reveal the site once the fill-in has finished
    const onFillDone = function(e){
      if (e.propertyName !== 'fill-opacity') return;
      outer.removeEventListener('transitionend', onFillDone);
      safeFinish();
    };
    outer.addEventListener('transitionend', onFillDone);

    // wait a frame so the browser registers the starting dashoffset
    // before we transition it, or the "draw" jumps straight to done
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        outer.style.transition = 'stroke-dashoffset 1.3s cubic-bezier(.65,0,.35,1)';
        drop.style.transition = 'stroke-dashoffset 1.0s cubic-bezier(.65,0,.35,1) 0.6s';
        outer.style.strokeDashoffset = '0';
        drop.style.strokeDashoffset = '0';
      });
    });

    // timer backup: if transitionend never fires for any reason
    // (interrupted transition, unusual browser behavior), don't strand the user
    setTimeout(safeFinish, 3400);
  } catch (err) {
    // if getTotalLength or anything else throws, don't strand the user
    finishLoading();
  }
})();

// ---- footer year ----
document.getElementById('year').textContent = new Date().getFullYear();

// ---- mobile nav toggle ----
const navToggle = document.getElementById('navToggle');
const navClose = document.getElementById('navClose');
const navLinks = document.getElementById('navLinks');

function openNav(){
  navLinks.classList.add('open');
  navToggle.setAttribute('aria-expanded', 'true');
  document.body.style.overflow = 'hidden';
  const firstLink = navLinks.querySelector('a');
  if (firstLink) firstLink.focus({ preventScroll: true });
}
function closeNav(returnFocus){
  navLinks.classList.remove('open');
  navToggle.setAttribute('aria-expanded', 'false');
  document.body.style.overflow = '';
  if (returnFocus) navToggle.focus({ preventScroll: true });
}

navToggle.addEventListener('click', () => {
  const isOpen = navLinks.classList.contains('open');
  if (isOpen) { closeNav(false); } else { openNav(); }
});
if (navClose) navClose.addEventListener('click', () => closeNav(true));

navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => closeNav(false));
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && navLinks.classList.contains('open')) {
    closeNav(true);
  }
});

// basic focus trap while the mobile menu is open
navLinks.addEventListener('keydown', (e) => {
  if (e.key !== 'Tab' || !navLinks.classList.contains('open')) return;
  const focusables = navLinks.querySelectorAll('a, button');
  if (!focusables.length) return;
  const first = focusables[0];
  const last = focusables[focusables.length - 1];
  if (e.shiftKey && document.activeElement === first) {
    e.preventDefault(); last.focus();
  } else if (!e.shiftKey && document.activeElement === last) {
    e.preventDefault(); first.focus();
  }
});

// ---- signature "peak" divider, echoing the logo's mountain silhouette ----
function buildPeakRule(el){
  const w = 1200, h = 14;
  const peaks = 24;
  const step = w / peaks;
  let d = `M0 ${h}`;
  for (let i = 0; i < peaks; i++){
    const x0 = i * step;
    const xMid = x0 + step / 2;
    const x1 = x0 + step;
    d += ` L${xMid} 0 L${x1} ${h}`;
  }
  el.innerHTML = `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
    <path d="${d}" fill="none" stroke="rgba(244,235,215,0.16)" stroke-width="1"/>
  </svg>`;
}
document.querySelectorAll('.peak-rule').forEach(buildPeakRule);

// ---- scroll progress bar ----
const scrollProgress = document.getElementById('scrollProgress');
function updateScrollProgress(){
  const scrollTop = window.scrollY;
  const docHeight = document.documentElement.scrollHeight - window.innerHeight;
  const pct = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
  if (scrollProgress) scrollProgress.style.width = pct + '%';
}
window.addEventListener('scroll', updateScrollProgress, { passive: true });
updateScrollProgress();

// ---- back to top ----
const backToTop = document.getElementById('backToTop');
function updateBackToTop(){
  if (!backToTop) return;
  if (window.scrollY > 700) backToTop.classList.add('visible');
  else backToTop.classList.remove('visible');
}
window.addEventListener('scroll', updateBackToTop, { passive: true });
updateBackToTop();
if (backToTop){
  backToTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: PREFERS_REDUCED_MOTION ? 'auto' : 'smooth' });
  });
}

// ---- scrollspy: highlight the nav link for the section in view ----
const navSpyLinks = Array.from(document.querySelectorAll('.nav-links a[data-nav]'));
const spySections = navSpyLinks
  .map(link => document.getElementById(link.dataset.nav))
  .filter(Boolean);

if ('IntersectionObserver' in window && spySections.length) {
  const spyObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const id = entry.target.id;
      navSpyLinks.forEach(link => {
        link.classList.toggle('active', link.dataset.nav === id);
      });
    });
  }, { rootMargin: '-45% 0px -50% 0px', threshold: 0 });
  spySections.forEach(section => spyObserver.observe(section));
}

// ---- project filter tabs ----
const filterTabs = document.querySelectorAll('.filter-tab');
const projectCards = document.querySelectorAll('.project-card');
const filterEmpty = document.getElementById('filterEmpty');

filterTabs.forEach(tab => {
  tab.addEventListener('click', () => {
    filterTabs.forEach(t => { t.classList.remove('active'); t.setAttribute('aria-pressed', 'false'); });
    tab.classList.add('active');
    tab.setAttribute('aria-pressed', 'true');

    const filter = tab.dataset.filter;
    let visibleCount = 0;
    projectCards.forEach(card => {
      const match = filter === 'all' || card.dataset.status === filter;
      card.classList.toggle('filtered-out', !match);
      if (match) visibleCount++;
    });
    if (filterEmpty) filterEmpty.hidden = visibleCount !== 0;
  });
});

// ---- copy email button ----
const copyEmailBtn = document.getElementById('copyEmailBtn');
if (copyEmailBtn) {
  copyEmailBtn.addEventListener('click', async () => {
    const email = copyEmailBtn.dataset.email;
    try {
      await navigator.clipboard.writeText(email);
    } catch (err) {
      // fallback for browsers without Clipboard API access
      const tmp = document.createElement('textarea');
      tmp.value = email;
      tmp.style.position = 'fixed';
      tmp.style.opacity = '0';
      document.body.appendChild(tmp);
      tmp.select();
      try { document.execCommand('copy'); } catch (e2) { /* no-op */ }
      document.body.removeChild(tmp);
    }
    copyEmailBtn.classList.add('copied');
    setTimeout(() => copyEmailBtn.classList.remove('copied'), 1800);
  });
}

// ---- newsletter form (no backend — opens a pre-filled email as a graceful fallback) ----
const newsletterForm = document.getElementById('newsletterForm');
const newsletterNote = document.getElementById('newsletterNote');
if (newsletterForm) {
  newsletterForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const emailInput = document.getElementById('newsletterEmail');
    const email = emailInput.value.trim();
    const validPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!validPattern.test(email)) {
      if (newsletterNote) {
        newsletterNote.textContent = 'That email doesn\'t look quite right — mind checking it?';
        newsletterNote.classList.add('error');
      }
      return;
    }
    if (newsletterNote) {
      newsletterNote.textContent = 'Opening your email app to confirm — thanks!';
      newsletterNote.classList.remove('error');
    }
    const subject = encodeURIComponent('Add me to Link with iQ updates');
    const body = encodeURIComponent(`Please add ${email} to the updates list.`);
    window.location.href = `mailto:linkwithiq@proton.me?subject=${subject}&body=${body}`;
    newsletterForm.reset();
  });
}

// ---- live GitHub stats on project cards ----
// Fetches directly from the browser to api.github.com — no backend, nothing
// proxied or logged on our end (matches what the Privacy Policy already
// discloses about how project-card stats work).
function formatRelativeDate(isoString) {
  const then = new Date(isoString);
  const days = Math.floor((Date.now() - then.getTime()) / 86400000);
  if (days <= 0) return 'today';
  if (days === 1) return '1 day ago';
  if (days < 30) return `${days} days ago`;
  const months = Math.floor(days / 30);
  if (months < 12) return `${months} mo ago`;
  const years = Math.floor(months / 12);
  return `${years} yr ago`;
}

async function loadProjectStats() {
  const cards = document.querySelectorAll('[data-repo]');
  const requests = Array.from(cards).map(async (card) => {
    const repo = card.dataset.repo;
    const statsEl = card.querySelector('.project-stats');
    if (!repo || !statsEl) return;
    try {
      const res = await fetch(`https://api.github.com/repos/${repo}`, {
        headers: { Accept: 'application/vnd.github+json' }
      });
      if (!res.ok) return; // rate-limited or not found — fail quietly, no fake data
      const data = await res.json();
      const stars = typeof data.stargazers_count === 'number' ? data.stargazers_count : null;
      const updated = data.pushed_at ? formatRelativeDate(data.pushed_at) : null;
      if (stars === null && !updated) return;
      const parts = [];
      if (stars !== null) parts.push(`★ ${stars}`);
      if (updated) parts.push(`updated ${updated}`);
      statsEl.textContent = parts.join(' · ');
      statsEl.hidden = false;
      // latest release tag, if the project has published one (silently skipped otherwise)
      try {
        const rel = await fetch(`https://api.github.com/repos/${repo}/releases/latest`, { headers: { Accept: 'application/vnd.github+json' } });
        if (rel.ok) {
          const tag = (await rel.json()).tag_name;
          if (typeof tag === 'string' && /^[\w.+-]{1,24}$/.test(tag)) {
            parts.push(`latest ${tag}`);
            statsEl.textContent = parts.join(' · ');
          }
        }
      } catch (e) { /* no release info: leave the stats as they are */ }
    } catch (err) {
      // network error, offline, blocked by an extension, etc. — leave hidden
    }
  });
  await Promise.all(requests);
}
// ---- project.html: fill the template from data/projects.js (?slug=...) ----
(function renderProjectPage(){
  const content = document.getElementById('projectContent');
  const notFound = document.getElementById('projectNotFound');
  if (!content || !notFound) return;
  const list = Array.isArray(window.LINKWITHIQ_PROJECTS) ? window.LINKWITHIQ_PROJECTS : [];
  const slug = new URLSearchParams(location.search).get('slug');
  const p = list.find(x => x && x.slug === slug);
  if (!p) { notFound.hidden = false; return; }

  const set = (id, text) => { const el = document.getElementById(id); if (el) el.textContent = text || ''; };
  const status = document.getElementById('pStatus');
  if (status) { status.className = 'project-status ' + (/^[a-z]+$/.test(p.status || '') ? p.status : ''); status.textContent = p.statusLabel || ''; }
  set('pName', p.name); set('pSummary', p.summary);
  set('pProblem', p.problem); set('pApproach', p.approach); set('pOutcome', p.outcome);
  const tags = document.getElementById('pTags');
  if (tags) (p.tags || []).forEach(t => { const span = document.createElement('span'); span.className = 'tag'; span.textContent = t; tags.appendChild(span); });

  const repoUrl = safeGitHubUrl('https://github.com/' + p.repo, ['github.com']);
  const link = document.getElementById('pRepoLink');
  if (link && repoUrl) link.href = repoUrl; else if (link) link.hidden = true;

  // live stats and contributors reuse the same GitHub loaders as the home page and Community page
  content.dataset.repo = p.repo;
  const stats = document.getElementById('pStats');
  if (stats) { stats.classList.remove('is-loading'); stats.textContent = ''; stats.hidden = true; }
  const avatars = document.getElementById('contributorAvatars');
  const contributors = document.getElementById('projectContributors');
  if (avatars) avatars.dataset.repos = p.repo;
  if (contributors) contributors.hidden = false;

  document.title = p.name + ' — Link with iQ';
  const desc = document.querySelector('meta[name="description"]');
  if (desc && p.summary) desc.setAttribute('content', p.summary);
  content.hidden = false;
  const body = document.getElementById('projectBody');
  if (body) body.hidden = false;
})();

if (document.querySelector('[data-repo]')) {
  loadProjectStats();
}

// ---- good first issue feed (community.html) ----
async function loadGoodFirstIssues() {
  const list = document.getElementById('goodFirstIssues');
  const fallback = document.getElementById('goodFirstIssuesFallback');
  if (!list) return;
  const org = list.dataset.org;
  if (!org) return;
  try {
    const q = encodeURIComponent(`org:${org} label:"good first issue" state:open type:issue`);
    const res = await fetch(`https://api.github.com/search/issues?q=${q}&per_page=10`, {
      headers: { Accept: 'application/vnd.github+json' }
    });
    if (!res.ok) throw new Error('request failed');
    const data = await res.json();
    const items = Array.isArray(data.items) ? data.items : [];
    if (items.length === 0) {
      if (fallback) fallback.hidden = false;
      return;
    }
    items.forEach(issue => {
      const li = document.createElement('li');
      li.className = 'issue-row';

      const link = document.createElement('a');
      link.href = safeGitHubUrl(issue.html_url, ['github.com']) || 'https://github.com/linkwithiq';
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.className = 'issue-title';
      link.textContent = issue.title;

      const meta = document.createElement('span');
      meta.className = 'issue-meta';
      const repoName = issue.repository_url ? issue.repository_url.split('/').pop() : '';
      meta.textContent = `${repoName} · #${issue.number}`;

      li.appendChild(link);
      li.appendChild(meta);
      list.appendChild(li);
    });
  } catch (err) {
    // couldn't load live data — say so honestly, never claim "nothing's open"
    // when we simply failed to check
    if (fallback) {
      fallback.textContent = '';
      fallback.appendChild(document.createTextNode("Couldn't load live issues right now — "));
      const link = document.createElement('a');
      link.href = 'https://github.com/linkwithiq';
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = 'browse repositories on GitHub';
      fallback.appendChild(link);
      fallback.appendChild(document.createTextNode(' directly.'));
      fallback.hidden = false;
    }
  }
}

// ---- contributor avatars (community.html, project.html) ----
async function loadContributorAvatars() {
  const container = document.getElementById('contributorAvatars');
  const fallback = document.getElementById('contributorFallback');
  if (!container) return;
  const repos = (container.dataset.repos || '').split(',').map(r => r.trim()).filter(Boolean);
  if (repos.length === 0) return; // no repo(s) specified yet — nothing to fetch
  try {
    const results = await Promise.all(repos.map(repo =>
      fetch(`https://api.github.com/repos/${repo}/contributors?per_page=30`, {
        headers: { Accept: 'application/vnd.github+json' }
      }).then(res => (res.ok ? res.json() : []))
    ));
    const seen = new Map();
    results.flat().forEach(c => {
      if (c && c.login && !seen.has(c.login)) seen.set(c.login, c);
    });
    const contributors = Array.from(seen.values());
    if (contributors.length === 0) {
      if (fallback) fallback.hidden = false;
      return;
    }
    contributors.forEach(c => {
      const a = document.createElement('a');
      a.href = safeGitHubUrl(c.html_url, ['github.com']) || 'https://github.com/linkwithiq';
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.className = 'contributor-avatar-link';
      a.title = c.login;
      const img = document.createElement('img');
      img.src = safeGitHubUrl(c.avatar_url, ['avatars.githubusercontent.com']) || '';
      img.alt = c.login;
      img.width = 40;
      img.height = 40;
      img.loading = 'lazy';
      a.appendChild(img);
      container.appendChild(a);
    });
  } catch (err) {
    if (fallback) {
      fallback.textContent = '';
      fallback.appendChild(document.createTextNode("Couldn't load contributor data right now — check "));
      const link = document.createElement('a');
      link.href = 'https://github.com/linkwithiq';
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = 'the repositories on GitHub';
      fallback.appendChild(link);
      fallback.appendChild(document.createTextNode(' directly.'));
      fallback.hidden = false;
    }
  }
}

if (document.getElementById('goodFirstIssues')) loadGoodFirstIssues();
if (document.getElementById('contributorAvatars')) loadContributorAvatars();

if (!PREFERS_REDUCED_MOTION && 'IntersectionObserver' in window) {
  const revealTargets = document.querySelectorAll(
    '.mission-card, .project-card, .resource-row, .process-step, .founder, .faq-item'
  );
  revealTargets.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(14px)';
    el.style.transition = 'opacity .5s ease, transform .5s ease';
  });
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  revealTargets.forEach(el => io.observe(el));
}

// ---- offline support: cache this site's own files so visited pages open without a connection ----
if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => { /* offline support is optional */ });
  });
}

// ---- "Report a problem": fill in which page the visitor was on (nothing is sent anywhere; it only builds the email) ----
document.querySelectorAll('.report-link').forEach(link => {
  const body = encodeURIComponent(`Page: ${location.href}\n\nWhat went wrong:\n`);
  link.href = `mailto:linkwithiq@proton.me?subject=${encodeURIComponent('Problem with ' + document.title)}&body=${body}`;
});

// ---- project.html: never leave a blank page if nothing has filled in the project template ----
window.addEventListener('load', () => {
  const content = document.getElementById('projectContent');
  const notFound = document.getElementById('projectNotFound');
  if (content && notFound && content.hidden && notFound.hidden) notFound.hidden = false;
});

// ---- comfortable reading: opt-in larger, more widely spaced text, remembered in this browser only ----
(function initComfort(){
  const btn = document.getElementById('comfortToggle');
  if (!btn) return;
  btn.hidden = false;
  const read = () => { try { return localStorage.getItem('liq-comfort') === '1'; } catch (e) { return false; } };
  const write = (on) => { try { if (on) localStorage.setItem('liq-comfort', '1'); else localStorage.removeItem('liq-comfort'); } catch (e) { /* storage unavailable: still works for this visit */ } };
  const apply = (on) => { document.documentElement.classList.toggle('comfy', on); btn.setAttribute('aria-pressed', String(on)); };
  apply(read());
  btn.addEventListener('click', () => { const on = !document.documentElement.classList.contains('comfy'); apply(on); write(on); });
})();
